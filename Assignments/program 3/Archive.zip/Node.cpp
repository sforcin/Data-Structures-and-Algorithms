// #include "Node.h"
// #include <iostream>

// using namespace std;

// Node::Node(const string& key) {
//     small = key;
//     large = "";
//     count = 1;
//     left = nullptr;
//     middle = nullptr;
//     right = nullptr;
//     parent = nullptr;
// }